class myclass:
  x1="priyanka" 
  def fun(self):
    print "hi i m inside the class"
    return 
f1=myclass()
f2=myclass()
f2.x1 = "arya" 
x= f1.fun()
print f1.x1 
print f2.x1 
